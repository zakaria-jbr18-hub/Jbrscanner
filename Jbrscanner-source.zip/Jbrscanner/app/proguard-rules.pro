# ML Kit and Play services ship their own consumer rules.
-keep class com.jbrscanner.app.data.** { *; }
