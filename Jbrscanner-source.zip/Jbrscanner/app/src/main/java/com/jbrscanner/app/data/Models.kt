package com.jbrscanner.app.data

import com.jbrscanner.app.imaging.FilterType
import org.json.JSONArray
import org.json.JSONObject

data class ScanPage(
    val id: String,
    val filter: FilterType = FilterType.ORIGINAL,
    val rotation: Int = 0,
    val version: Int = 0,
) {
    val originalFileName: String get() = "orig_$id.jpg"
    val renderedFileName: String get() = "page_${id}_v$version.jpg"

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("filter", filter.name)
        .put("rotation", rotation)
        .put("version", version)

    companion object {
        fun fromJson(o: JSONObject) = ScanPage(
            id = o.getString("id"),
            filter = runCatching { FilterType.valueOf(o.optString("filter")) }.getOrDefault(FilterType.ORIGINAL),
            rotation = o.optInt("rotation", 0),
            version = o.optInt("version", 0),
        )
    }
}

data class ScanDocument(
    val id: String,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val pages: List<ScanPage>,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("createdAt", createdAt)
        .put("updatedAt", updatedAt)
        .put("pages", JSONArray().apply { pages.forEach { put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): ScanDocument {
            val arr = o.optJSONArray("pages") ?: JSONArray()
            return ScanDocument(
                id = o.getString("id"),
                name = o.optString("name", "Scan"),
                createdAt = o.optLong("createdAt"),
                updatedAt = o.optLong("updatedAt"),
                pages = (0 until arr.length()).map { ScanPage.fromJson(arr.getJSONObject(it)) },
            )
        }
    }
}
