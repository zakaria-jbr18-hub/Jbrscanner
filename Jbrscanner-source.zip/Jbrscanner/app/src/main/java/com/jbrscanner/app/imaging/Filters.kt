package com.jbrscanner.app.imaging

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint

enum class FilterType(val label: String) {
    ORIGINAL("Original"),
    AUTO("Auto"),
    CLEAN("Clean doc"),
    BRIGHT("Bright"),
    GRAY("Grayscale"),
    BW("B&W"),
}

object Filters {

    fun apply(src: Bitmap, type: FilterType): Bitmap = when (type) {
        FilterType.ORIGINAL -> src
        FilterType.AUTO -> colorMatrix(src, contrast(1.25f, 8f).also { it.postConcat(saturation(1.25f)) })
        FilterType.BRIGHT -> colorMatrix(src, contrast(1.1f, 35f))
        FilterType.GRAY -> colorMatrix(src, saturation(0f).also { it.postConcat(contrast(1.15f, 5f)) })
        FilterType.CLEAN -> whitenBackground(src)
        FilterType.BW -> adaptiveThreshold(src)
    }

    /** Scales channels around mid-grey by [scale] and then adds [offset] (0..255 space). */
    private fun contrast(scale: Float, offset: Float): ColorMatrix {
        val t = (1f - scale) * 128f + offset
        return ColorMatrix(
            floatArrayOf(
                scale, 0f, 0f, 0f, t,
                0f, scale, 0f, 0f, t,
                0f, 0f, scale, 0f, t,
                0f, 0f, 0f, 1f, 0f,
            )
        )
    }

    private fun saturation(s: Float) = ColorMatrix().apply { setSaturation(s) }

    private fun colorMatrix(src: Bitmap, m: ColorMatrix): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { colorFilter = ColorMatrixColorFilter(m) }
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }

    private fun luminance(c: Int): Int {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        return (r * 299 + g * 587 + b * 114) / 1000
    }

    /** Builds an integral image of the luminance so local means can be read in O(1). */
    private fun integral(gray: IntArray, w: Int, h: Int): IntArray {
        val sums = IntArray((w + 1) * (h + 1))
        for (y in 1..h) {
            var row = 0
            for (x in 1..w) {
                row += gray[(y - 1) * w + (x - 1)]
                sums[y * (w + 1) + x] = sums[(y - 1) * (w + 1) + x] + row
            }
        }
        return sums
    }

    private inline fun forEachLocalMean(gray: IntArray, w: Int, h: Int, block: (index: Int, value: Int, mean: Int) -> Unit) {
        val sums = integral(gray, w, h)
        val half = maxOf(8, maxOf(w, h) / 32)
        for (y in 0 until h) {
            val y0 = maxOf(0, y - half)
            val y1 = minOf(h, y + half + 1)
            for (x in 0 until w) {
                val x0 = maxOf(0, x - half)
                val x1 = minOf(w, x + half + 1)
                val area = (x1 - x0) * (y1 - y0)
                val sum = sums[y1 * (w + 1) + x1] - sums[y0 * (w + 1) + x1] - sums[y1 * (w + 1) + x0] + sums[y0 * (w + 1) + x0]
                val i = y * w + x
                block(i, gray[i], sum / area)
            }
        }
    }

    /** Black-and-white document look: Bradley adaptive threshold, robust to uneven lighting. */
    private fun adaptiveThreshold(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val gray = IntArray(px.size) { luminance(px[it]) }
        forEachLocalMean(gray, w, h) { i, v, mean ->
            px[i] = if (v * 100 < mean * 88) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /**
     * Keeps colour but removes shadows and paper tint: each pixel is divided by its local
     * background brightness, so paper becomes white while ink and stamps keep their colour.
     */
    private fun whitenBackground(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val gray = IntArray(px.size) { luminance(px[it]) }
        forEachLocalMean(gray, w, h) { i, _, mean ->
            val bg = maxOf(mean + 12, 40).coerceAtMost(255)
            val c = px[i]
            val r = whiten((c shr 16) and 0xFF, bg)
            val g = whiten((c shr 8) and 0xFF, bg)
            val b = whiten(c and 0xFF, bg)
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun whiten(v: Int, bg: Int): Int {
        val n = v * 255 / bg
        // Steepen the curve so faint text darkens and near-white turns fully white
        val s = ((n - 128) * 13 / 10) + 128 + 10
        return s.coerceIn(0, 255)
    }
}
