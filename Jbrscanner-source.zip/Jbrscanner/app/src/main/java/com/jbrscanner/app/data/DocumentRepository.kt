package com.jbrscanner.app.data

import android.content.Context
import android.net.Uri
import com.jbrscanner.app.imaging.FilterType
import com.jbrscanner.app.imaging.ImageUtils
import com.jbrscanner.app.imaging.Filters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Stores every document as a folder under filesDir/documents/<id>/ holding:
 *  - meta.json            name, dates, ordered pages with their filter and rotation
 *  - orig_<page>.jpg      the cropped, perspective-corrected capture (never modified)
 *  - page_<page>_vN.jpg   the rendered page (rotation + filter applied)
 */
class DocumentRepository(private val context: Context) {

    private val root = File(context.filesDir, "documents").apply { mkdirs() }
    private val mutex = Mutex()
    private val _documents = MutableStateFlow<List<ScanDocument>>(emptyList())
    val documents: StateFlow<List<ScanDocument>> = _documents.asStateFlow()

    suspend fun load() = withContext(Dispatchers.IO) {
        mutex.withLock {
            val docs = root.listFiles()?.mapNotNull { dir ->
                val meta = File(dir, META)
                if (!meta.exists()) null
                else runCatching { ScanDocument.fromJson(JSONObject(meta.readText())) }.getOrNull()
            } ?: emptyList()
            _documents.value = docs.sortedByDescending { it.updatedAt }
        }
    }

    fun dirOf(docId: String) = File(root, docId)
    fun pageFile(docId: String, page: ScanPage) = File(dirOf(docId), page.renderedFileName)
    fun find(docId: String) = _documents.value.firstOrNull { it.id == docId }

    suspend fun createFromImages(uris: List<Uri>): ScanDocument = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val dir = dirOf(id).apply { mkdirs() }
        val pages = uris.map { importPage(dir, it) }
        val name = "Scan " + SimpleDateFormat("yyyy-MM-dd HH.mm", Locale.getDefault()).format(Date(now))
        val doc = ScanDocument(id, name, now, now, pages)
        save(doc)
        doc
    }

    suspend fun addPages(docId: String, uris: List<Uri>) = withContext(Dispatchers.IO) {
        val doc = find(docId) ?: return@withContext
        val pages = uris.map { importPage(dirOf(docId), it) }
        save(doc.copy(pages = doc.pages + pages, updatedAt = System.currentTimeMillis()))
    }

    suspend fun rename(docId: String, name: String) = update(docId) { it.copy(name = name.trim().ifEmpty { it.name }) }

    suspend fun delete(docId: String) = withContext(Dispatchers.IO) {
        mutex.withLock {
            dirOf(docId).deleteRecursively()
            _documents.value = _documents.value.filterNot { it.id == docId }
        }
    }

    suspend fun setFilter(docId: String, pageId: String, filter: FilterType) =
        rerender(docId, pageId) { it.copy(filter = filter) }

    suspend fun rotate(docId: String, pageId: String) =
        rerender(docId, pageId) { it.copy(rotation = (it.rotation + 90) % 360) }

    suspend fun applyFilterToAll(docId: String, filter: FilterType) {
        val doc = find(docId) ?: return
        doc.pages.forEach { setFilter(docId, it.id, filter) }
    }

    suspend fun deletePage(docId: String, pageId: String) = withContext(Dispatchers.IO) {
        val doc = find(docId) ?: return@withContext
        val page = doc.pages.firstOrNull { it.id == pageId } ?: return@withContext
        if (doc.pages.size == 1) {
            delete(docId)
            return@withContext
        }
        File(dirOf(docId), page.originalFileName).delete()
        File(dirOf(docId), page.renderedFileName).delete()
        save(doc.copy(pages = doc.pages - page, updatedAt = System.currentTimeMillis()))
    }

    suspend fun movePage(docId: String, from: Int, to: Int) = update(docId) { doc ->
        if (from !in doc.pages.indices || to !in doc.pages.indices) doc
        else doc.copy(pages = doc.pages.toMutableList().apply { add(to, removeAt(from)) })
    }

    private suspend fun rerender(docId: String, pageId: String, change: (ScanPage) -> ScanPage) =
        withContext(Dispatchers.IO) {
            val doc = find(docId) ?: return@withContext
            val old = doc.pages.firstOrNull { it.id == pageId } ?: return@withContext
            val dir = dirOf(docId)
            val new = change(old).copy(version = old.version + 1)
            render(dir, new)
            File(dir, old.renderedFileName).delete()
            save(doc.copy(pages = doc.pages.map { if (it.id == pageId) new else it }, updatedAt = System.currentTimeMillis()))
        }

    private suspend fun update(docId: String, change: (ScanDocument) -> ScanDocument) = withContext(Dispatchers.IO) {
        val doc = find(docId) ?: return@withContext
        save(change(doc).copy(updatedAt = System.currentTimeMillis()))
    }

    private fun importPage(dir: File, uri: Uri): ScanPage {
        val page = ScanPage(id = UUID.randomUUID().toString().take(12))
        val bitmap = ImageUtils.decodeSampled(context, uri, MAX_DIMENSION)
            ?: error("Could not read scanned image")
        ImageUtils.saveJpeg(bitmap, File(dir, page.originalFileName))
        ImageUtils.saveJpeg(bitmap, File(dir, page.renderedFileName))
        bitmap.recycle()
        return page
    }

    private fun render(dir: File, page: ScanPage) {
        val original = ImageUtils.decodeFile(File(dir, page.originalFileName), MAX_DIMENSION)
            ?: error("Missing original page")
        val rotated = ImageUtils.rotate(original, page.rotation)
        val filtered = Filters.apply(rotated, page.filter)
        ImageUtils.saveJpeg(filtered, File(dir, page.renderedFileName))
        if (filtered !== rotated) filtered.recycle()
        if (rotated !== original) rotated.recycle()
        original.recycle()
    }

    private suspend fun save(doc: ScanDocument) = mutex.withLock {
        val dir = dirOf(doc.id).apply { mkdirs() }
        val tmp = File(dir, "$META.tmp")
        tmp.writeText(doc.toJson().toString())
        tmp.renameTo(File(dir, META))
        _documents.value = (_documents.value.filterNot { it.id == doc.id } + doc).sortedByDescending { it.updatedAt }
    }

    companion object {
        private const val META = "meta.json"
        const val MAX_DIMENSION = 2400
    }
}
