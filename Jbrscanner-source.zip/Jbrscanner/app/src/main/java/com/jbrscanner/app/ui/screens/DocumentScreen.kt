package com.jbrscanner.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextSnippet
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.jbrscanner.app.ScannerViewModel
import com.jbrscanner.app.export.PageSize
import com.jbrscanner.app.imaging.FilterType
import com.jbrscanner.app.ui.Share
import com.jbrscanner.app.ui.rememberDocumentScanner
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScreen(viewModel: ScannerViewModel, docId: String, onBack: () -> Unit) {
    val docs by viewModel.documents.collectAsStateWithLifecycle()
    val busy by viewModel.busy.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()
    val doc = docs.firstOrNull { it.id == docId }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }

    var menu by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var confirmDeleteDoc by remember { mutableStateOf(false) }
    var confirmDeletePage by remember { mutableStateOf(false) }
    var ocrText by remember { mutableStateOf<String?>(null) }
    var pageSize by remember { mutableStateOf(PageSize.A4) }

    // The document disappears after it is deleted (or its last page is removed)
    var hadDoc by remember { mutableStateOf(false) }
    LaunchedEffect(doc == null) {
        if (doc != null) hadDoc = true else if (hadDoc) onBack()
    }
    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); viewModel.consumeMessage() }
    }
    if (doc == null) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
        return
    }

    val pager = rememberPagerState(pageCount = { doc.pages.size })
    val currentIndex = pager.currentPage.coerceIn(0, (doc.pages.size - 1).coerceAtLeast(0))
    val currentPage = doc.pages.getOrNull(currentIndex)

    val addPages = rememberDocumentScanner { uris -> viewModel.addPages(docId, uris) }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) viewModel.savePdfTo(docId, uri, pageSize)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                },
                title = {
                    Text(doc.name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.clickable { renaming = true })
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.exportPdf(docId, pageSize) { Share.files(context, listOf(it), "application/pdf", doc.name) }
                    }) { Icon(Icons.Filled.Share, contentDescription = "Share PDF") }
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Save PDF to device") }, onClick = {
                                menu = false; savePdf.launch(doc.name + ".pdf")
                            })
                            DropdownMenuItem(text = { Text("Share as images") }, onClick = {
                                menu = false
                                viewModel.exportImages(docId) { Share.files(context, it, "image/jpeg", doc.name) }
                            })
                            DropdownMenuItem(text = { Text("PDF page size: ${pageSize.label}") }, onClick = {
                                pageSize = PageSize.entries[(pageSize.ordinal + 1) % PageSize.entries.size]
                            })
                            DropdownMenuItem(text = { Text("Extract text from all pages") }, onClick = {
                                menu = false; viewModel.recognizeText(docId, null) { ocrText = it }
                            })
                            DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; renaming = true })
                            DropdownMenuItem(text = { Text("Delete document") }, onClick = { menu = false; confirmDeleteDoc = true })
                        }
                    }
                },
            )
        },
        bottomBar = {
            Column(Modifier.background(MaterialTheme.colorScheme.surface)) {
                FilterRow(
                    selected = currentPage?.filter ?: FilterType.ORIGINAL,
                    onSelect = { f -> currentPage?.let { viewModel.setFilter(docId, it.id, f) } },
                    onApplyAll = { currentPage?.let { viewModel.applyFilterToAll(docId, it.filter) } },
                    showApplyAll = doc.pages.size > 1,
                )
                NavigationBar {
                    NavigationBarItem(selected = false, onClick = { addPages() },
                        icon = { Icon(Icons.Filled.AddAPhoto, null) }, label = { Text("Add") })
                    NavigationBarItem(selected = false, onClick = { currentPage?.let { viewModel.rotate(docId, it.id) } },
                        icon = { Icon(Icons.Filled.RotateRight, null) }, label = { Text("Rotate") })
                    NavigationBarItem(selected = false, onClick = {
                        viewModel.recognizeText(docId, currentIndex) { ocrText = it }
                    }, icon = { Icon(Icons.Filled.TextSnippet, null) }, label = { Text("Text") })
                    NavigationBarItem(selected = false, onClick = {
                        viewModel.exportPdf(docId, pageSize) { Share.files(context, listOf(it), "application/pdf", doc.name) }
                    }, icon = { Icon(Icons.Filled.PictureAsPdf, null) }, label = { Text("PDF") })
                    NavigationBarItem(selected = false, onClick = { confirmDeletePage = true },
                        icon = { Icon(Icons.Filled.Delete, null) }, label = { Text("Delete") })
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = Color(0xFF2A3131),
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { index ->
                val page = doc.pages.getOrNull(index)
                if (page != null) {
                    AsyncImage(
                        model = viewModel.repository.pageFile(docId, page),
                        contentDescription = "Page ${index + 1}",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                    )
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(
                    enabled = currentIndex > 0,
                    onClick = {
                        viewModel.movePage(docId, currentIndex, currentIndex - 1)
                        scope.launch { pager.animateScrollToPage(currentIndex - 1) }
                    },
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Move page left", tint = Color.White) }
                Surface(shape = RoundedCornerShape(16.dp), color = Color.Black.copy(alpha = 0.4f)) {
                    Text(
                        "${currentIndex + 1} / ${doc.pages.size}",
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                    )
                }
                IconButton(
                    enabled = currentIndex < doc.pages.size - 1,
                    onClick = {
                        viewModel.movePage(docId, currentIndex, currentIndex + 1)
                        scope.launch { pager.animateScrollToPage(currentIndex + 1) }
                    },
                ) { Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Move page right", tint = Color.White) }
            }
        }
    }

    if (renaming) RenameDialog(doc.name, onDismiss = { renaming = false }) { viewModel.rename(docId, it) }
    if (confirmDeleteDoc) ConfirmDialog(
        "Delete document?", "All ${doc.pages.size} page(s) will be removed.", "Delete",
        onDismiss = { confirmDeleteDoc = false },
    ) { viewModel.delete(docId) }
    if (confirmDeletePage && currentPage != null) ConfirmDialog(
        "Delete page ${currentIndex + 1}?",
        if (doc.pages.size == 1) "This is the only page, so the document will be deleted." else "This page will be removed from the document.",
        "Delete",
        onDismiss = { confirmDeletePage = false },
    ) { viewModel.deletePage(docId, currentPage.id) }
    ocrText?.let { text -> OcrDialog(text, doc.name, context, onDismiss = { ocrText = null }) }
}

@Composable
private fun FilterRow(selected: FilterType, onSelect: (FilterType) -> Unit, onApplyAll: () -> Unit, showApplyAll: Boolean) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(FilterType.entries) { f ->
            FilterChip(selected = f == selected, onClick = { onSelect(f) }, label = { Text(f.label) })
        }
        if (showApplyAll) {
            item { TextButton(onClick = onApplyAll) { Text("Apply to all") } }
        }
    }
}

@Composable
private fun OcrDialog(text: String, title: String, context: Context, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Recognized text") },
        text = {
            SelectionContainer {
                Text(text, modifier = Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()))
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText(title, text))
                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                }) { Text("Copy") }
                TextButton(onClick = { Share.text(context, text, title) }) { Text("Share") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
