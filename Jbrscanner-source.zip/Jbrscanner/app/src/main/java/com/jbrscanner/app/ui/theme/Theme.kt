package com.jbrscanner.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val BrandTeal = Color(0xFF0E7C7B)
val BrandNavy = Color(0xFF12355B)
val BrandAmber = Color(0xFFF2A541)

private val Light = lightColorScheme(
    primary = BrandTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFBFE3E2),
    onPrimaryContainer = Color(0xFF00201F),
    secondary = BrandNavy,
    onSecondary = Color.White,
    tertiary = BrandAmber,
    onTertiary = Color(0xFF2B1700),
    background = Color(0xFFF6F8F8),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE3EBEA),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6FD1CF),
    onPrimary = Color(0xFF003736),
    primaryContainer = Color(0xFF005150),
    onPrimaryContainer = Color(0xFFBFE3E2),
    secondary = Color(0xFFA6C8F0),
    onSecondary = Color(0xFF0A2540),
    tertiary = BrandAmber,
    onTertiary = Color(0xFF2B1700),
    background = Color(0xFF0F1414),
    surface = Color(0xFF151B1B),
    surfaceVariant = Color(0xFF253030),
)

@Composable
fun JbrTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
