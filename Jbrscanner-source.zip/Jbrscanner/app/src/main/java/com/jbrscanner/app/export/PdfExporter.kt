package com.jbrscanner.app.export

import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import com.jbrscanner.app.data.ScanDocument
import com.jbrscanner.app.imaging.ImageUtils
import java.io.File
import java.io.OutputStream

enum class PageSize(val label: String, val widthPt: Int, val heightPt: Int) {
    A4("A4", 595, 842),
    LETTER("Letter", 612, 792),
    FIT("Fit image", 0, 0),
}

object PdfExporter {

    /** Writes every page of [doc] into one PDF. Each image is centred with a small margin. */
    fun write(doc: ScanDocument, pageFile: (Int) -> File, out: OutputStream, size: PageSize = PageSize.A4) {
        val pdf = PdfDocument()
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        try {
            doc.pages.indices.forEach { index ->
                val bitmap = ImageUtils.decodeFile(pageFile(index), 2000) ?: return@forEach
                val landscape = bitmap.width > bitmap.height
                val (pw, ph) = when (size) {
                    PageSize.FIT -> {
                        // 150 dpi equivalent keeps file size reasonable
                        val scale = 72f / 150f
                        (bitmap.width * scale).toInt() to (bitmap.height * scale).toInt()
                    }
                    else -> if (landscape) size.heightPt to size.widthPt else size.widthPt to size.heightPt
                }
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(pw, ph, index + 1).create())
                val margin = if (size == PageSize.FIT) 0f else 18f
                val availW = pw - 2 * margin
                val availH = ph - 2 * margin
                val ratio = minOf(availW / bitmap.width, availH / bitmap.height)
                val dw = bitmap.width * ratio
                val dh = bitmap.height * ratio
                val left = (pw - dw) / 2f
                val top = (ph - dh) / 2f
                page.canvas.drawBitmap(bitmap, null, RectF(left, top, left + dw, top + dh), paint)
                pdf.finishPage(page)
                bitmap.recycle()
            }
            pdf.writeTo(out)
        } finally {
            pdf.close()
        }
    }
}
