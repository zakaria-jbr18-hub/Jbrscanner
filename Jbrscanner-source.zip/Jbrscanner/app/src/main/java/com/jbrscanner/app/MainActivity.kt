package com.jbrscanner.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jbrscanner.app.ui.screens.DocumentScreen
import com.jbrscanner.app.ui.screens.HomeScreen
import com.jbrscanner.app.ui.theme.JbrTheme

class MainActivity : ComponentActivity() {
    private val viewModel: ScannerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JbrTheme {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(viewModel, onOpen = { id -> nav.navigate("doc/$id") })
                    }
                    composable("doc/{id}") { entry ->
                        val id = entry.arguments?.getString("id").orEmpty()
                        DocumentScreen(viewModel, id, onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
