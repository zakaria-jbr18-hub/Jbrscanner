package com.jbrscanner.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jbrscanner.app.data.DocumentRepository
import com.jbrscanner.app.data.ScanDocument
import com.jbrscanner.app.export.PageSize
import com.jbrscanner.app.export.PdfExporter
import com.jbrscanner.app.imaging.FilterType
import com.jbrscanner.app.imaging.ImageUtils
import com.jbrscanner.app.ocr.OcrEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ScannerViewModel(app: Application) : AndroidViewModel(app) {

    val repository = DocumentRepository(app)
    val documents: StateFlow<List<ScanDocument>> = repository.documents

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    init {
        viewModelScope.launch { repository.load() }
    }

    fun consumeMessage() { _message.value = null }

    private fun work(block: suspend () -> Unit) {
        viewModelScope.launch {
            _busy.value = true
            try {
                block()
            } catch (e: Exception) {
                _message.value = e.message ?: "Something went wrong"
            } finally {
                _busy.value = false
            }
        }
    }

    fun createFromScan(uris: List<Uri>, onCreated: (String) -> Unit) = work {
        if (uris.isEmpty()) return@work
        val doc = repository.createFromImages(uris)
        onCreated(doc.id)
    }

    fun addPages(docId: String, uris: List<Uri>) = work { repository.addPages(docId, uris) }
    fun setFilter(docId: String, pageId: String, filter: FilterType) = work { repository.setFilter(docId, pageId, filter) }
    fun applyFilterToAll(docId: String, filter: FilterType) = work { repository.applyFilterToAll(docId, filter) }
    fun rotate(docId: String, pageId: String) = work { repository.rotate(docId, pageId) }
    fun movePage(docId: String, from: Int, to: Int) = work { repository.movePage(docId, from, to) }
    fun deletePage(docId: String, pageId: String) = work { repository.deletePage(docId, pageId) }
    fun rename(docId: String, name: String) = work { repository.rename(docId, name) }
    fun delete(docId: String) = work { repository.delete(docId) }

    /** Renders the document to a PDF in the shareable cache folder. */
    fun exportPdf(docId: String, size: PageSize = PageSize.A4, onReady: (File) -> Unit) = work {
        val doc = repository.find(docId) ?: return@work
        val file = withContext(Dispatchers.IO) {
            val dir = File(getApplication<Application>().cacheDir, "exports").apply { mkdirs() }
            val out = File(dir, safeName(doc.name) + ".pdf")
            out.outputStream().use { stream ->
                PdfExporter.write(doc, { repository.pageFile(docId, doc.pages[it]) }, stream, size)
            }
            out
        }
        onReady(file)
    }

    /** Writes the PDF straight to a location the user picked with the system file picker. */
    fun savePdfTo(docId: String, target: Uri, size: PageSize = PageSize.A4) = work {
        val doc = repository.find(docId) ?: return@work
        withContext(Dispatchers.IO) {
            getApplication<Application>().contentResolver.openOutputStream(target)?.use { stream ->
                PdfExporter.write(doc, { repository.pageFile(docId, doc.pages[it]) }, stream, size)
            }
        }
        _message.value = "PDF saved"
    }

    /** Copies the rendered page images to the cache folder so they can be shared as JPEGs. */
    fun exportImages(docId: String, onReady: (List<File>) -> Unit) = work {
        val doc = repository.find(docId) ?: return@work
        val files = withContext(Dispatchers.IO) {
            val dir = File(getApplication<Application>().cacheDir, "exports").apply { mkdirs() }
            doc.pages.mapIndexed { i, page ->
                val out = File(dir, "${safeName(doc.name)}_${i + 1}.jpg")
                repository.pageFile(docId, page).copyTo(out, overwrite = true)
            }
        }
        onReady(files)
    }

    fun recognizeText(docId: String, pageIndex: Int?, onResult: (String) -> Unit) = work {
        val doc = repository.find(docId) ?: return@work
        val indices = if (pageIndex == null) doc.pages.indices.toList() else listOf(pageIndex)
        val parts = indices.mapNotNull { i ->
            val page = doc.pages.getOrNull(i) ?: return@mapNotNull null
            val bmp = withContext(Dispatchers.IO) {
                ImageUtils.decodeFile(repository.pageFile(docId, page), DocumentRepository.MAX_DIMENSION)
            } ?: return@mapNotNull null
            val text = OcrEngine.recognize(bmp)
            bmp.recycle()
            if (indices.size > 1) "--- Page ${i + 1} ---\n$text" else text
        }
        onResult(parts.joinToString("\n\n").ifBlank { "No text found on this page." })
    }

    private fun safeName(name: String) = name.replace(Regex("[^A-Za-z0-9 _.-]"), "_").trim().ifEmpty { "Jbrscanner" }
}
