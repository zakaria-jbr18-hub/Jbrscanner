# Jbrscanner

An Android document scanner: capture paper documents with the camera, get clean, flat,
readable pages, and share them as PDFs.

## Features

- **Smart capture**: live camera scanning with automatic page edge detection, adjustable
  corners, and perspective correction (on-device, Google ML Kit Document Scanner). Photos can
  also be imported from the gallery.
- **Multi-page documents**: scan many pages at once, add more later, reorder, rotate, delete.
- **Filters**: Original, Auto, Clean doc (removes shadows and paper tint, keeps colour),
  Bright, Grayscale, and B&W (adaptive threshold that copes with uneven lighting). Apply to
  one page or to all pages. Originals are always kept, so filters can be changed any time.
- **PDF export**: A4, Letter, or fit-to-image pages. Share directly or save to any folder.
- **OCR**: extract text from one page or the whole document, offline. Copy or share it.
- **Library**: thumbnails, search, rename, delete.
- Light and dark themes, no account, no ads, nothing leaves the phone unless you share it.

## Requirements

- Android 8.0 (API 26) or newer, with Google Play services (used by the scanner and OCR models).

## Build the APK

### Option A: GitHub Actions (no setup)
Push this project to a GitHub repository. The **Build APK** workflow runs on every push.
Open the run under the **Actions** tab and download `Jbrscanner-debug-apk`.

### Option B: Android Studio
1. Install Android Studio (Ladybug or newer).
2. File > Open, choose this folder, and let Gradle sync.
3. Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

### Option C: Command line
Requires JDK 17+ and the Android SDK (set `ANDROID_HOME` or create `local.properties`
with `sdk.dir=/path/to/Android/sdk`).

```
./gradlew assembleDebug
```

## Install on a phone
Copy `app-debug.apk` to the phone, open it, and allow "Install unknown apps" when asked.

## Release build
Create a signing key (`keytool -genkey -v -keystore jbrscanner.jks -keyalg RSA -keysize 2048 -validity 10000 -alias jbrscanner`),
add a `signingConfigs` block to `app/build.gradle.kts`, then run `./gradlew assembleRelease`
(or `bundleRelease` for Google Play).

## Project layout

```
app/src/main/java/com/jbrscanner/app/
  MainActivity.kt          navigation
  ScannerViewModel.kt      actions used by the screens
  data/                    documents stored as folders with a JSON index
  imaging/                 decoding, rotation and the filter engine
  export/PdfExporter.kt    multi-page PDF writer
  ocr/OcrEngine.kt         on-device text recognition
  ui/                      Compose screens, scanner launcher, sharing
```
